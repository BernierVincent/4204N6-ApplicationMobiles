package org.deguet.retrofit2_demo.transfer;

public class Repo {

    String name;
    Long id;
}
