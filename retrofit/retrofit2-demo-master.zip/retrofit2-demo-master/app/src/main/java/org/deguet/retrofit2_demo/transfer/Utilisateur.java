package org.deguet.retrofit2_demo.transfer;

public class Utilisateur {

    public String login;
    public Long id;
    public Long followers;
}
